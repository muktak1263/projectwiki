var session_8php =
[
    [ "SessionManager", "class_session_manager.html", "class_session_manager" ],
    [ "$session", "session_8php.html#abefb3c26429d514777313e9a63d7cbac", null ]
];