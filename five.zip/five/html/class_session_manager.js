var class_session_manager =
[
    [ "__construct", "class_session_manager.html#a095c5d389db211932136b53f25f39685", null ],
    [ "__destruct", "class_session_manager.html#a421831a265621325e1fdd19aace0c758", null ],
    [ "close", "class_session_manager.html#aa69c8bf1f1dcf4e72552efff1fe3e87e", null ],
    [ "destroy", "class_session_manager.html#a7976894a2e2239ff937a9203c383c9c1", null ],
    [ "gc", "class_session_manager.html#a14ff7ef4b198ff14884dd8c564264ca3", null ],
    [ "open", "class_session_manager.html#a037c59224bcb347b69ca61df88ef7230", null ],
    [ "read", "class_session_manager.html#a379d9c87c852c5901ff1976be29a5048", null ],
    [ "write", "class_session_manager.html#ad7b615bb92609350d2d9d0c07f6f58ed", null ],
    [ "COLLECTION", "class_session_manager.html#a4e794644048b7d488d370f82e65a0f27", null ],
    [ "SESSION_COOKIE_DOMAIN", "class_session_manager.html#a09e73e23a624b4b7fbcfc3ba7495da3e", null ],
    [ "SESSION_COOKIE_PATH", "class_session_manager.html#a165a17d584c91b3a410212a531644d0b", null ],
    [ "SESSION_LIFESPAN", "class_session_manager.html#a4cf65f80cfb11832f032736095aec9e3", null ],
    [ "SESSION_NAME", "class_session_manager.html#ac15063c1be0036865bc582b411fe04de", null ],
    [ "SESSION_TIMEOUT", "class_session_manager.html#a2545f82887886bf14a6c226b7a354270", null ]
];