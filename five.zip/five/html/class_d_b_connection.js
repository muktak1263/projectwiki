var class_d_b_connection =
[
    [ "getCollection", "class_d_b_connection.html#a4fc50b13bb68c05297fbc51529d7d4f6", null ],
    [ "$connection", "class_d_b_connection.html#a0d9c79b9b86b3f5891c6d3892f12c6a0", null ],
    [ "$database", "class_d_b_connection.html#a7691c0162d89de0b6ba47edcd8ba8878", null ],
    [ "DBNAME", "class_d_b_connection.html#af7d219badcc93cc3a13a604c769542bc", null ],
    [ "HOST", "class_d_b_connection.html#a6768772c01f2d4f111fabd25012e8259", null ],
    [ "PORT", "class_d_b_connection.html#ab9a2d2c70deaf0f75cf0ee531f6ed0b5", null ]
];