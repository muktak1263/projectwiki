var addarticle_8php =
[
    [ "$c", "addarticle_8php.html#ab73d7f4f2dae233dd561e7fdaab3a77b", null ],
    [ "$col", "addarticle_8php.html#adfa09a2a4bcf32780a44eaa8c070c81d", null ],
    [ "$collection", "addarticle_8php.html#ab9e21dbbe588414048003c715034e2aa", null ],
    [ "$cursor", "addarticle_8php.html#a256b6d58b346bcd39d5bf5d49de70df2", null ],
    [ "$data", "addarticle_8php.html#a7ff7f47b3e1ecd45b15f3afebb6fa9e2", null ],
    [ "$db", "addarticle_8php.html#a1fa3127fc82f96b1436d871ef02be319", null ],
    [ "$server", "addarticle_8php.html#ad135cc8a47e55f0829949cf62214170f", null ],
    [ "else", "addarticle_8php.html#a945357e3fb251bfc6fe310847e1dc33c", null ],
    [ "foreach", "addarticle_8php.html#a387f3584b331f6259fd9b56bfd383d11", null ]
];