var searchData=
[
  ['open',['open',['../class_session_manager.html#a037c59224bcb347b69ca61df88ef7230',1,'SessionManager']]]
];
