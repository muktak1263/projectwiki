var searchData=
[
  ['instantiate',['instantiate',['../class_d_b_connection.html#afec0dd46f9a181363a54347c646f8d3c',1,'DBConnection']]]
];
