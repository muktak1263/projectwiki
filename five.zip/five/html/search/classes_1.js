var searchData=
[
  ['sessionmanager',['SessionManager',['../class_session_manager.html',1,'']]]
];
