var searchData=
[
  ['destroy',['destroy',['../class_session_manager.html#a7976894a2e2239ff937a9203c383c9c1',1,'SessionManager']]]
];
