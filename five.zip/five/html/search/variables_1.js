var searchData=
[
  ['collection',['COLLECTION',['../class_session_manager.html#a4e794644048b7d488d370f82e65a0f27',1,'SessionManager']]]
];
