var searchData=
[
  ['foreach',['foreach',['../addarticle_8php.html#a387f3584b331f6259fd9b56bfd383d11',1,'foreach():&#160;addarticle.php'],['../addtopic_8php.html#affbbd484ed05d7571ceb3d2418bc8548',1,'foreach():&#160;addtopic.php']]]
];
