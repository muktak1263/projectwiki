var searchData=
[
  ['close',['close',['../class_session_manager.html#aa69c8bf1f1dcf4e72552efff1fe3e87e',1,'SessionManager']]]
];
