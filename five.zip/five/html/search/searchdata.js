var indexSectionsWithContent =
{
  0: "$_acdefghiloprsvw",
  1: "ds",
  2: "adilpsv",
  3: "_cdgiorw",
  4: "$cdefhips"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

