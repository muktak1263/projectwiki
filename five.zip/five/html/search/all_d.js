var searchData=
[
  ['read',['read',['../class_session_manager.html#a379d9c87c852c5901ff1976be29a5048',1,'SessionManager']]]
];
