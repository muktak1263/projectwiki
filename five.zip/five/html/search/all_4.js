var searchData=
[
  ['dbconnection',['DBConnection',['../class_d_b_connection.html',1,'']]],
  ['dbconnection_2ephp',['dbconnection.php',['../dbconnection_8php.html',1,'']]],
  ['dbname',['DBNAME',['../class_d_b_connection.html#af7d219badcc93cc3a13a604c769542bc',1,'DBConnection']]],
  ['destroy',['destroy',['../class_session_manager.html#a7976894a2e2239ff937a9203c383c9c1',1,'SessionManager']]]
];
