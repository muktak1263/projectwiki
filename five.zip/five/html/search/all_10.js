var searchData=
[
  ['write',['write',['../class_session_manager.html#ad7b615bb92609350d2d9d0c07f6f58ed',1,'SessionManager']]]
];
