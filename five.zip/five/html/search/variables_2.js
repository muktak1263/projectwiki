var searchData=
[
  ['dbname',['DBNAME',['../class_d_b_connection.html#af7d219badcc93cc3a13a604c769542bc',1,'DBConnection']]]
];
