var searchData=
[
  ['_5f_5fconstruct',['__construct',['../class_session_manager.html#a095c5d389db211932136b53f25f39685',1,'SessionManager']]],
  ['_5f_5fdestruct',['__destruct',['../class_session_manager.html#a421831a265621325e1fdd19aace0c758',1,'SessionManager']]]
];
