var searchData=
[
  ['if',['if',['../profile_8php.html#ac67905b879bd576ab3bba74eacfb71c7',1,'profile.php']]],
  ['index_2ephp',['index.php',['../index_8php.html',1,'']]],
  ['instantiate',['instantiate',['../class_d_b_connection.html#afec0dd46f9a181363a54347c646f8d3c',1,'DBConnection']]]
];
