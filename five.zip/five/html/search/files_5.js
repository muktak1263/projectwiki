var searchData=
[
  ['session_2ephp',['session.php',['../session_8php.html',1,'']]]
];
