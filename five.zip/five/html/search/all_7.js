var searchData=
[
  ['gc',['gc',['../class_session_manager.html#a14ff7ef4b198ff14884dd8c564264ca3',1,'SessionManager']]],
  ['getcollection',['getCollection',['../class_d_b_connection.html#a4fc50b13bb68c05297fbc51529d7d4f6',1,'DBConnection']]]
];
