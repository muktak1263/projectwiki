var searchData=
[
  ['session_2ephp',['session.php',['../session_8php.html',1,'']]],
  ['session_5fcookie_5fdomain',['SESSION_COOKIE_DOMAIN',['../class_session_manager.html#a09e73e23a624b4b7fbcfc3ba7495da3e',1,'SessionManager']]],
  ['session_5fcookie_5fpath',['SESSION_COOKIE_PATH',['../class_session_manager.html#a165a17d584c91b3a410212a531644d0b',1,'SessionManager']]],
  ['session_5flifespan',['SESSION_LIFESPAN',['../class_session_manager.html#a4cf65f80cfb11832f032736095aec9e3',1,'SessionManager']]],
  ['session_5fname',['SESSION_NAME',['../class_session_manager.html#ac15063c1be0036865bc582b411fe04de',1,'SessionManager']]],
  ['session_5ftimeout',['SESSION_TIMEOUT',['../class_session_manager.html#a2545f82887886bf14a6c226b7a354270',1,'SessionManager']]],
  ['sessionmanager',['SessionManager',['../class_session_manager.html',1,'']]]
];
