var annotated_dup =
[
    [ "DBConnection", "class_d_b_connection.html", "class_d_b_connection" ],
    [ "SessionManager", "class_session_manager.html", "class_session_manager" ]
];