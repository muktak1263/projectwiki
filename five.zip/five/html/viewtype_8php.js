var viewtype_8php =
[
    [ "$c", "viewtype_8php.html#ab73d7f4f2dae233dd561e7fdaab3a77b", null ],
    [ "$collection", "viewtype_8php.html#ab9e21dbbe588414048003c715034e2aa", null ],
    [ "$cursor", "viewtype_8php.html#a256b6d58b346bcd39d5bf5d49de70df2", null ],
    [ "$data", "viewtype_8php.html#a6efc15b5a2314dd4b5aaa556a375c6d6", null ],
    [ "$db", "viewtype_8php.html#a1fa3127fc82f96b1436d871ef02be319", null ],
    [ "$server", "viewtype_8php.html#ad135cc8a47e55f0829949cf62214170f", null ]
];