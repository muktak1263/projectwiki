var logout_8php =
[
    [ "$user", "logout_8php.html#a598ca4e71b15a1313ec95f0df1027ca5", null ],
    [ "exit", "logout_8php.html#a6733eb5f605d09eaede9845835d71c4e", null ]
];