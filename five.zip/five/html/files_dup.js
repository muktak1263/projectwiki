var files_dup =
[
    [ "addarticle.php", "addarticle_8php.html", "addarticle_8php" ],
    [ "addplatform.php", "addplatform_8php.html", null ],
    [ "addtopic.php", "addtopic_8php.html", "addtopic_8php" ],
    [ "addtype.php", "addtype_8php.html", null ],
    [ "adduser.php", "adduser_8php.html", null ],
    [ "dbconnection.php", "dbconnection_8php.html", [
      [ "DBConnection", "class_d_b_connection.html", "class_d_b_connection" ]
    ] ],
    [ "index.php", "index_8php.html", "index_8php" ],
    [ "logout.php", "logout_8php.html", "logout_8php" ],
    [ "profile.php", "profile_8php.html", "profile_8php" ],
    [ "session.php", "session_8php.html", "session_8php" ],
    [ "viewplat.php", "viewplat_8php.html", "viewplat_8php" ],
    [ "viewtype.php", "viewtype_8php.html", "viewtype_8php" ],
    [ "viewuser.php", "viewuser_8php.html", "viewuser_8php" ]
];