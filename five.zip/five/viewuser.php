

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/skin-blue.min.css">
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
  
</head>
<body class="hold-transition skin-blue sidebar-mini">

            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
               <?php
               require_once "../vendor/autoload.php";

             $server = "mongodb://localhost:27017/database";
 
                   $c = new MongoDB\Client( $server );
                   global $data;
                   $data .= "<tr>";
                   $data .= "<thead>";
                   $data .= "<th>Name</th>";
        				   $data .= "<th>View Platform</th>";
                   $data .= "<th>Add Platofrom</th>";
                   $data .= "<th>Delete Platfprm</th>";
                    $data .= "<th>View Title</th>";
                   $data .= "<th>Add Title</th>";
                   $data .= "<th>Delete Title</th>";
                    $data .= "<th>View Topic</th>";
                   $data .= "<th>Add Topic</th>";
                   $data .= "<th>Delete Topic</th>";
                    $data .= "<th>View User</th>";
                   $data .= "<th>Add User</th>";
                   $data .= "<th>Delete User</th>";
                   $data .= "<th>EDIT</th>";
                    $data .= "<th>DELETE</th>";
                  $data .= "<thead>";
                $data .= "</tr>";
               $data .= "<tbody>";
                 $db = $c->database;
               $collection = $db->users;
               $cursor = $collection->find();
                 foreach($cursor as $document){
            $data .= "<tr>";
            $data .= "<td>" . $document["name"] ."<br>" . $document["email"]."<br>" . $document["phone"]. "</td>";
        
       
            $data .= "<td>" . $document["platview"]."</td>";
            $data .= "<td>" . $document["platadd"]."</td>";
            $data .= "<td>" . $document["platdelete"]."</td>";

             $data .= "<td>" . $document["titleview"]."</td>";
            $data .= "<td>" . $document["titleadd"]."</td>";
            $data .= "<td>" . $document["titledelete"]."</td>";

              $data .= "<td>" . $document["topicview"]."</td>";
            $data .= "<td>" . $document["topicadd"]."</td>";
            $data .= "<td>" . $document["topicdelete"]."</td>";


            $data .= "<td>" . $document["userview"]."</td>";
            $data .= "<td>" . $document["useradd"]."</td>";
            $data .= "<td>" . $document["userdelete"]."</td>";



            $data .= "</tr>";
        }
        $data .= "</tbody>";
        $data .= "</table>";
        echo $data;  ?>
              </table>
            </div>
            <!-- /.box-body -->
         
  </body>
</html>